package com.example.firebase_application;

import android.content.Intent;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;


public class Mypage extends Fragment {
     Button btn1,btn2,btn3,btn4;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        ViewGroup viewGroup;
        viewGroup = (ViewGroup) inflater.inflate(R.layout.mypage,container,false);
        btn4=viewGroup.findViewById(R.id.mypage_btn4);
        btn3=viewGroup.findViewById(R.id.mypage_btn3);
        btn1=viewGroup.findViewById(R.id.mypage_btn1);
        btn2 =viewGroup.findViewById(R.id.mypage_btn2);



        btn4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(getActivity(), Myinform.class);
                startActivity(intent);

            }
        });
        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(getActivity(),Trade.class);
                startActivity(intent);

            }
        });


        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(getActivity(), Productcontrol.class);
                startActivity(intent);

            }
        });

        btn3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(getActivity(), Messagehome.class);
                startActivity(intent);

            }
        });


        return  viewGroup;

    }
}
