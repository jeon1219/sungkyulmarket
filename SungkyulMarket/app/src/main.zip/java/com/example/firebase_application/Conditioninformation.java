package com.example.firebase_application;

import android.view.View;

import java.util.HashMap;
import java.util.Map;

public class Conditioninformation {
    public String imv;
    public String name;
    public String id;
    public String item;
    public String money;
    public String text;
    public String buyeremail;
    public  String useremail;
    public String date;
    public  String category;
    public   String state;
    public String reviewcheck;

    public String getReviewcheck() {
        return reviewcheck;
    }

    public void setReviewcheck(String reviewcheck) {
        this.reviewcheck = reviewcheck;
    }



    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public String getItem() {
        return item;
    }

    public void setItem(String item) {
        this.item = item;
    }

    public String getImv() {
        return imv;
    }

    public void setImv(String imv) {
        this.imv = imv;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }



    public String getMoney() {
        return money;
    }

    public void setMoney(String money) {
        this.money = money;
    }



    public String getBuyeremail() {
        return buyeremail;
    }

    public void setBuyeremail(String buyeremail) { this.buyeremail = buyeremail; }


    public String getUseremail() {
        return useremail;
    }


    public void setUseremail(String useremail) {
        this.useremail = useremail;
    }


    public void setDate(String date) {
        this.date = date;
    }
    public String getDate() {
        return date;
    }

    public void setState(String state) {
        this.state = state;
    }
    public String getState() {
        return state;
    }

    public void setCategory(String category) {
        this.category = category;
    }
    public String getCategory() {
        return category;
    }



    public Conditioninformation(){

    }

}
