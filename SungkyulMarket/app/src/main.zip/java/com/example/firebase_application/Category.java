package com.example.firebase_application;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import static android.app.PendingIntent.getActivity;


public class Category extends AppCompatActivity {

    private Button setting_btn1;
    private RadioGroup setting_rdogroup;
    private RadioButton setting_rdobtn1;
    private RadioButton setting_rdobtn2;
    private RadioButton setting_rdobtn3;
    private RadioButton setting_rdobtn4;
    private RadioButton setting_rdobtn5;
    private RadioButton setting_rdobtn6;
    private RadioButton setting_rdobtn7;
    private RadioButton setting_rdobtn8;
    private String category;


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.category);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setTitle("\t\t\t\t성결장터");
        getSupportActionBar().setIcon(R.drawable.sk);
        setting_btn1 = findViewById(R.id.setting_btn1);

        setting_btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                search();
                Intent intent = new Intent(getApplicationContext(), Main.class);
                startActivity(intent);



            }
        });
    }



    public void search(){



            final Productinformation product = new Productinformation();

        setting_rdogroup =findViewById(R.id.setting_rdogroup);
        setting_rdobtn1 = findViewById(R.id.setting_rdobtn1);
        setting_rdobtn2 = findViewById(R.id.setting_rdobtn2);
        setting_rdobtn3 = findViewById(R.id.setting_rdobtn3);
        setting_rdobtn4 = findViewById(R.id.setting_rdobtn4);
        setting_rdobtn5 = findViewById(R.id.setting_rdobtn5);
        setting_rdobtn6 = findViewById(R.id.setting_rdobtn6);
        setting_rdobtn7 = findViewById(R.id.setting_rdobtn7);
        setting_rdobtn8 = findViewById(R.id.setting_rdobtn8);




        int id = setting_rdogroup.getCheckedRadioButtonId();

        if (id == R.id.setting_rdobtn1) {
           category = setting_rdobtn1.getText().toString();
        } else if (id == R.id.setting_rdobtn2) {
            category = setting_rdobtn2.getText().toString();
        } else if (id == R.id.setting_rdobtn3) {
            category = setting_rdobtn3.getText().toString();
        }else if (id == R.id.setting_rdobtn4) {
            category = setting_rdobtn4.getText().toString();
        } else if (id == R.id.setting_rdobtn5) {
            category = setting_rdobtn5.getText().toString();
        } else if (id == R.id.setting_rdobtn6) {
            category = setting_rdobtn6.getText().toString();
        } else if (id == R.id.setting_rdobtn7) {
            category = setting_rdobtn7.getText().toString();
        } else if (id == R.id.setting_rdobtn8) {
            category = setting_rdobtn8.getText().toString();
        }

//product2에 선택한 값 들어감감

        DatabaseReference mDBReference = null;

        mDBReference = FirebaseDatabase.getInstance().getReference();
        mDBReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                // This method is called once with the initial value and again
                // whenever data at this location is updated.
                Log.d("Database", "Value is: " + product);
                Toast.makeText(Category.this, category , Toast.LENGTH_LONG).show();
            }

            @Override
            public void onCancelled(DatabaseError error) {
                // Failed to read value
                Log.w("Database", "Failed to read value.", error.toException());
            }
        });





   }



}