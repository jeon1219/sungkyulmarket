package com.example.firebase_application;

import java.util.HashMap;
import java.util.Map;

public class Messageinformation {
    public String text;
    public String date;
    public String buyeremail;
    public String selleremail;

    public Messageinformation() {

    }

    public Messageinformation( String text, String date, String buyeremail, String selleremail) {
        this.text = text;
        this.date = date;
        this.buyeremail = buyeremail;
        this.selleremail = selleremail;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String review) {
        this.date = date;
    }


    public String getBuyeremail() {
        return buyeremail;
    }

    public void setBuyeremail(String buyeremail) {
        this.buyeremail = buyeremail;
    }

    public String getSelleremail() {
        return selleremail;
    }

    public void setSelleremail(String selleremail) {
        this.selleremail = selleremail;
    }


}
