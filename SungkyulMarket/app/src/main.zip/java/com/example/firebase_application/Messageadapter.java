package com.example.firebase_application;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;

public class Messageadapter extends RecyclerView.Adapter<Messageadapter.CustomViewHolder>  {
    private ArrayList<Productinformation>arrayList2;

    private Context context;
    private FirebaseDatabase database;
    private DatabaseReference databaseReference;
    private Object Context;
    private FirebaseUser user;
    private  String uid;

    private ArrayList<Integer> userlist=new ArrayList<Integer>();



    public Messageadapter(ArrayList<Productinformation> arrayList, Context context) {
        this.arrayList2 = arrayList;
        this.context = context;
    }
    @NonNull
    @Override
    public CustomViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.basket_list_item,parent,false);
        CustomViewHolder holder= new CustomViewHolder(view);
        return holder;
    }
    @Override
    public void onBindViewHolder(@NonNull final CustomViewHolder holder, final int position) {
        Glide.with(holder.itemView)
                .load(arrayList2.get(position).getImv())
                .into(holder.iv_image);
        holder.tv_name.setText(arrayList2.get(position).getName());
        holder.tv_useremail.setText(arrayList2.get(position).getUseremail());
        holder.tv_money.setText(String.valueOf(arrayList2.get(position).getMoney()));

        final String name= (String) holder.tv_name.getText();

        holder.customadapter2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                database=FirebaseDatabase.getInstance();//파이어베이스 데이터베이스 연동
                user = FirebaseAuth.getInstance().getCurrentUser();
                uid = user.getUid();//해당 유저 UID 받아옴
                databaseReference = database.getReference("User").child(uid).child("basket").child(name); //DB테이블 연결
                databaseReference.setValue(null);

            }
        });

    }
    @Override
    public int getItemCount() {
        //삼항 연산자
        return (arrayList2 !=null ? arrayList2.size():0);
    }
    public class CustomViewHolder extends RecyclerView.ViewHolder {
        ImageView iv_image;
        TextView tv_name;
        TextView tv_useremail;
        TextView tv_money;
        Button customadapter2;
        public CustomViewHolder(@NonNull View itemView) {
            super(itemView);
            this.iv_image=itemView.findViewById(R.id.iv_image2);
            this.tv_name=itemView.findViewById(R.id.tv_name2);
            this.tv_useremail=itemView.findViewById(R.id.tv_id2);
            this.tv_money=itemView.findViewById(R.id.tv_money2);
            this.customadapter2=itemView.findViewById(R.id.activity_list2_btn);



        }


    }
}
