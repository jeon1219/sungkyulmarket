
package com.example.firebase_application;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class Messagelook<getActivity> extends AppCompatActivity {


    private RecyclerView recyclerView;

    private FirebaseDatabase database;
    private DatabaseReference databaseReference,data2;
    private FirebaseAuth auth=FirebaseAuth.getInstance();
    private FirebaseUser user;
    private  String uid,uid2;
    private RecyclerView.Adapter adapter;
    private ArrayList<Productinformation> messageList=new ArrayList<>(); //물품객체를 담을 어레이 리스트 (어댑터쪽으로);

    public static Context CONTEXT;//새로고침 위한 전역변수


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.messagelook);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setTitle("\t\t\t\t성결장터");
        getSupportActionBar().setIcon(R.drawable.sk);
        CONTEXT = this;//새로고침할 액티비티 지정

        TextView tv1=findViewById(R.id.messagelook_tv1);//상대아이디
        TextView tv2=findViewById(R.id.messagelook_tv2);//날짜
        TextView tv3=findViewById(R.id.messagelook_tv3);//내용



        Button btn1=findViewById(R.id.messagelook_btn1); //답장버튼
        Button btn2=findViewById(R.id.messagelook_btn2); //삭제버튼

        Intent intent=getIntent();
        tv1.setText("아이디: "+intent.getStringExtra("receiveemail"));
        tv2.setText("날짜: "+intent.getStringExtra("date"));
        tv3.setText("내용: "+intent.getStringExtra("text"));



        btn1.setOnClickListener(new View.OnClickListener() { //답장클릭
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(getApplicationContext(),Messagesend.class);
                startActivity(intent);
            }
        });



        final String receiveemail = intent.getStringExtra("receiveemail");
        final String text = intent.getStringExtra("text");
        final String date = intent.getStringExtra("date");


        user = FirebaseAuth.getInstance().getCurrentUser();


        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {//<>

                FirebaseDatabase mDatabase;
                DatabaseReference dataRef;

                mDatabase = FirebaseDatabase.getInstance();
                dataRef = mDatabase.getReference("Message");
                dataRef.removeValue();

            }
        });//<>


    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.login, menu);

        return true;
    }

    @Override
    public boolean onPrepareOptionsMenu(Menu menu) {
        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        if (user != null) {//지금 로그인된 유저가 있다면
            menu.findItem(R.id.action_logout).setVisible(true);
            menu.findItem(R.id.action_login).setVisible(false);

        } else {
            menu.findItem(R.id.action_logout).setVisible(false);
            menu.findItem(R.id.action_login).setVisible(true);

        }
        return super.onPrepareOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {

            case R.id.action_logout:

            case R.id.action_login:
                if (FirebaseAuth.getInstance().getCurrentUser() == null) {
                    Intent intent = new Intent(getApplicationContext(), Login.class);
                    startActivity(intent);
                } else {
                    LogoutAsk();

                }
                return true;
            // ...
            // ...
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    public void LogoutAsk() {
        AlertDialog.Builder dlg = new AlertDialog.Builder(this);
        dlg.setTitle("알림");
        dlg.setMessage("로그아웃을 하시겠습니까?");
        dlg.setIcon(R.mipmap.ic_launcher);
        dlg.setPositiveButton("확인", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                FirebaseAuth.getInstance().signOut();
                onRestart();
                invalidateOptionsMenu();
                tostmsg();

            }
        });
        dlg.setNegativeButton("취소", null);
        dlg.show();

    //    adapter = new Messagesendadapter(messageList, getApplication());
    //    recyclerView.setAdapter(adapter);//리사이클러뷰에 어댑터 연결


    }


    public void tostmsg() {
        Toast.makeText(this, "로그아웃이 되었습니다.", Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onResume() { //새로고침
        super.onResume();
    }


}
