package com.example.firebase_application;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import android.app.AlertDialog;
import androidx.recyclerview.widget.RecyclerView;
import com.bumptech.glide.Glide;
import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import com.orhanobut.dialogplus.ViewHolder;
import com.orhanobut.dialogplus.DialogPlus;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class Tradeinformationadapter extends FirebaseRecyclerAdapter<Conditioninformation,Tradeinformationadapter.CustomViewHolder> {

    public Tradeinformationadapter(@NonNull FirebaseRecyclerOptions<Conditioninformation> options) { super(options); }

    @Override
    protected void onBindViewHolder(@NonNull final CustomViewHolder holder,final int position, @NonNull final Conditioninformation model) {

      /*  Glide.with(holder.condition_imv.getContext())
                .load(model.getImv())
                .into(holder.condition_imv);*/

        holder.condition_postname.setText(model.getName());
        holder.condition_useremail.setText(model.getUseremail());
        holder.condition_money.setText(model.getMoney());
        holder.condition_date.setText(model.getDate());

        holder.btnsell.setOnClickListener(new View.OnClickListener() { //평가 보기 버튼 클릭시
            @Override
            public void onClick(View v) {
                final DialogPlus dialogPlus=DialogPlus.newDialog(holder.itemView.getContext())
                        .setContentHolder(new ViewHolder(R.layout.seller))
                        .setExpanded(true, WindowManager.LayoutParams.MATCH_PARENT) //다이어로그 화면 꽉채우기
                        .create();

                final View myview=dialogPlus.getHolderView();

                final RatingBar seller_rb1=myview.findViewById(R.id.seller_rb1);
                final EditText seller_edt1=myview.findViewById(R.id.seller_edt1);
                final TextView seller_tv1=myview.findViewById(R.id.seller_tv1);
                seller_tv1.setText(holder.condition_postname.getText());
                Button seller_btn1=myview.findViewById(R.id.seller_btn1);

                dialogPlus.show();

                // 평가 버튼 클릭시 해당 타임스탬프 값 읽어오기 -> 이런식으로도 사용가능
                /*String timekey;
                  timekey =FirebaseDatabase.getInstance().getReference().child("Trade information")
                        .child(getRef(position).getKey()).getKey();*/

                //Toast.makeText(myview.getContext(), timekey, Toast.LENGTH_SHORT).show();

                //평가 완료버튼 클릭시
                seller_btn1.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        String selleremail= (String) holder.condition_useremail.getText().toString().trim(); //판매자 이메일
                        String review=seller_edt1.getText().toString().trim(); //리뷰 내용
                        String postname=seller_tv1.getText().toString().trim(); // 게시글
                        String rating=Float.toString(seller_rb1.getRating()); // 별점
                        //현재 나의 이메일 가져오기(구매자)
                        String buyeremail;
                        FirebaseUser useremail = FirebaseAuth.getInstance().getCurrentUser();
                        buyeremail = useremail.getEmail();

                        Map<String,Object> map=new HashMap<>();
                        map.put("postname",postname);
                        map.put("buyeremail",buyeremail);
                        map.put("selleremail",selleremail);
                        map.put("review",review);
                        map.put("rating",rating);

                        //평가 완료 시 Review Table에 값 저장
                        FirebaseDatabase.getInstance().getReference().child("Review").push().setValue(map);

                        // 리뷰작성을 하면 Trade information에 있는 값 삭제
                        FirebaseDatabase.getInstance().getReference().child("Trade information")
                                .child(getRef(position).getKey()).removeValue();

                        Toast.makeText(myview.getContext(), "리뷰를 작성했습니다.", Toast.LENGTH_SHORT).show();

                        dialogPlus.dismiss();
                    }
                });

            }
        });


    }

    @NonNull
    @Override
    public CustomViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view=LayoutInflater.from(parent.getContext()).inflate(R.layout.sell_list_item,parent,false);
        return new CustomViewHolder(view);
    }

    public class CustomViewHolder extends RecyclerView.ViewHolder {
        ImageView condition_imv;
        TextView condition_postname;
        TextView condition_money;
        TextView condition_date;
        TextView condition_useremail;
        Button btnsell;

        public CustomViewHolder(@NonNull  View itemView) {
            super(itemView);
            condition_imv=itemView.findViewById(R.id.conditionlistitem_imv1);
            condition_postname=itemView.findViewById(R.id.conditionlistitem_tv3);
            condition_money=itemView.findViewById(R.id.conditionlistitem_tv5);
            condition_date=itemView.findViewById(R.id.conditionlistitem_tv6);
            condition_useremail =itemView.findViewById(R.id.conditionlistitem_tv4);
            btnsell=itemView.findViewById(R.id.sell_list_item_btn1);
        }

    }
}
