package com.example.firebase_application;

import android.os.Bundle;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.FirebaseDatabase;

public class Messagehomesend extends AppCompatActivity {

    private RecyclerView recyclerView;
    private Messagesendadapter adapter;
    private RecyclerView.LayoutManager layoutManager;


    String email;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.send);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setTitle("\t\t\t\t성결장터");
        getSupportActionBar().setIcon(R.drawable.sk);

        recyclerView=findViewById(R.id.send_rv);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        recyclerView.setHasFixedSize(true);//리사이클러뷰 기존성능 강화

        layoutManager=new LinearLayoutManager(getApplication());
        recyclerView.setLayoutManager(layoutManager);

//        recyclerView.setOnClickListener();

        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        email = user.getEmail();


        if (user != null) {//지금 로그인된 유저가 있다면
            FirebaseRecyclerOptions<Productinformation> options =
                    new FirebaseRecyclerOptions.Builder<Productinformation>()
                            .setQuery(FirebaseDatabase.getInstance().getReference().child("Message").orderByChild("sendemail").equalTo(email), Productinformation.class).build();
            adapter=new Messagesendadapter(options);
            recyclerView.setAdapter(adapter);//리사이클러뷰에 어댑터 연결
        }
        else{
            Toast.makeText(getApplicationContext(),"로그인을 해야합니다.",Toast.LENGTH_SHORT).show();
        }
    }


    @Override
    protected void onStart() {
        super.onStart();
        adapter.startListening();

    }

    @Override
    protected void onStop() {
        super.onStop();
        adapter.startListening();
    }
}
