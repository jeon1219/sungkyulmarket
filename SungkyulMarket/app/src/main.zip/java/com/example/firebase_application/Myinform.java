package com.example.firebase_application;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class Myinform extends AppCompatActivity {
    Button btn1,btn2,btn3;
    TextView tv1,tv2,tv3,tv4,tv5,tv6;
    private FirebaseDatabase database;
    private DatabaseReference databaseReference;
    String uid = null;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.myinform);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setTitle("\t\t\t\t성결장터");
        getSupportActionBar().setIcon(R.drawable.sk);
        btn1=findViewById(R.id.myinform_btn1);
        btn2=findViewById(R.id.myinform_btn2);
        tv1=findViewById(R.id.myinform_tv2);
        tv2=findViewById(R.id.myinform_tv4);
        tv3=findViewById(R.id.myinform_tv6);
        tv4=findViewById(R.id.myinform_tv8);

        tv6=findViewById(R.id.myinform_tv12);
        btn3=findViewById(R.id.myinform_btn3);



        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(getApplicationContext(), Myinformchange.class);
                startActivity(intent);

            }
        });
        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(getApplicationContext(), Repass.class);
                startActivity(intent);

            }
        });

        btn3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                {
                    AlertDialog.Builder dlg = new AlertDialog.Builder(Myinform.this);
                    dlg.setTitle("알림");
                    dlg.setMessage("회원탈퇴를 하시겠습니까?");
                    dlg.setIcon(R.mipmap.ic_launcher);
                    dlg.setPositiveButton("확인", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
                            user.delete()
                                    .addOnCompleteListener(new OnCompleteListener<Void>() {
                                        @Override
                                        public void onComplete(@NonNull Task<Void> task) {
                                            if (task.isSuccessful()) {

                                            }
                                        }
                                    });

                            Intent intent=new Intent(getApplicationContext(),Main.class);
                            startActivity(intent);
                            finish();

                        }

                    });
                    dlg.setNegativeButton("취소", null);
                    dlg.show();
                }

            }
        });


        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        if (user != null) {

            String name = user.getDisplayName();
            String email = user.getEmail();
            Uri photoUrl = user.getPhotoUrl();


            boolean emailVerified = user.isEmailVerified();

            String uid = user.getUid();
            tv6.setText(email);
        }


        if (user != null) {
            uid = user.getUid();//해당 유저 UID 받아옴
            database = FirebaseDatabase.getInstance();//파이어베이스 데이터베이스 연동


                    databaseReference = database.getReference("User_information"); //DB테이블 연결
                    databaseReference.child(uid).child("name").addValueEventListener(new ValueEventListener() {//해당유저의 닉네임을 받아오는 메소드
                        @Override
                        public void onDataChange(@NonNull DataSnapshot snapshot) {
                            String str = snapshot.getValue(String.class);
                            //해당 유저 닉네임을 받아서 보여줌
                            if (str != null) {
                                tv1.setText(str);



                            } else {


                            }
                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError error) {

                        }
                    });
            databaseReference.child(uid).child("school").addValueEventListener(new ValueEventListener() {//해당유저의 닉네임을 받아오는 메소드
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {
                    String str2 = snapshot.getValue(String.class);
                    //해당 유저 닉네임을 받아서 보여줌
                    if (str2 != null) {
                        tv2.setText(str2);



                    } else {


                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {

                }
            });
            databaseReference.child(uid).child("major").addValueEventListener(new ValueEventListener() {//해당유저의 닉네임을 받아오는 메소드
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {
                    String str3 = snapshot.getValue(String.class);
                    //해당 유저 닉네임을 받아서 보여줌
                    if (str3 != null) {
                        tv3.setText(str3);



                    } else {


                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {

                }
            });

            databaseReference.child(uid).child("number").addValueEventListener(new ValueEventListener() {//해당유저의 닉네임을 받아오는 메소드
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {
                    String str4 = snapshot.getValue(String.class);
                    //해당 유저 닉네임을 받아서 보여줌
                    if (str4 != null) {
                        tv4.setText(str4);



                    } else {


                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {

                }
            });



        }

}
}
