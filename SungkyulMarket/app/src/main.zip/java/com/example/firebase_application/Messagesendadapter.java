package com.example.firebase_application;

import android.app.Application;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import android.app.AlertDialog;
import androidx.recyclerview.widget.RecyclerView;
import com.bumptech.glide.Glide;
import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import com.orhanobut.dialogplus.ViewHolder;
import com.orhanobut.dialogplus.DialogPlus;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class Messagesendadapter extends FirebaseRecyclerAdapter<Productinformation,Messagesendadapter.CustomViewHolder> {
    private ArrayList<Productinformation> arrayList;


    public Messagesendadapter(@NonNull FirebaseRecyclerOptions<Productinformation> options) {
        super(options);
        this.arrayList = arrayList;
        this.context = context;

    }

    private Context context;


    @Override
    protected void onBindViewHolder(@NonNull final CustomViewHolder holder,final int position, @NonNull final Productinformation model) {

      /*  Glide.with(holder.condition_imv.getContext())
                .load(model.getImv())
                .into(holder.condition_imv);*/


        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();

        holder.text.setText(model.getText());
        holder.receiveemail.setText(model.getReceiveemail());
        holder.date.setText(model.getDate());

/*
        final String text=arrayList.get(position).getText();
        final String date=arrayList.get(position).getText();
        final String recevieemail=arrayList.get(position).getText();
*/
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(context, Messagelook.class);

                final String text=arrayList.get(position).getText();
                final String date=arrayList.get(position).getText();
                final String receiveemail=arrayList.get(position).getText();

                intent.putExtra("receiveemail",receiveemail);
                intent.putExtra("date",date);
                intent.putExtra("text",text);


                context.startActivity(intent);
            }
        });


        /*
        holder.delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email;


                FirebaseDatabase mDatabase;
                DatabaseReference dataRef;

                mDatabase = FirebaseDatabase.getInstance();
                FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
                email = user.getEmail();

                dataRef = (DatabaseReference) mDatabase.getReference("Message").orderByChild("sendemail").equalTo(email);
                dataRef.removeValue();

            }
        });
*/





    }

    @NonNull
    @Override
    public CustomViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View view=LayoutInflater.from(parent.getContext()).inflate(R.layout.send_list_item,parent,false);
        return new CustomViewHolder(view);

    }

    public class CustomViewHolder extends RecyclerView.ViewHolder {
        TextView text;
        TextView date;
        TextView receiveemail;
        Button delete;


        public CustomViewHolder(@NonNull  View itemView) {
            super(itemView);
            receiveemail=itemView.findViewById(R.id.messagesendlistitem_tv1);
            date=itemView.findViewById(R.id.messagesendlistitem_tv2);
            text=itemView.findViewById(R.id.messagesendlistitem_tv3);
            this.delete=itemView.findViewById(R.id.messagesendlistitem_btn1);







        }

    }
}
